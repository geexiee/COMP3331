./q3 tests/graph1 0 2 | sort -n

