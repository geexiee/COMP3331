./q1 1 < tests/tree2
