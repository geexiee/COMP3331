./q2 < tests/t7.in | sort
